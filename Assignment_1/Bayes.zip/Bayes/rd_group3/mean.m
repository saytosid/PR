function [M] = mean(X)

M = sum(X)/length(X);

end;
